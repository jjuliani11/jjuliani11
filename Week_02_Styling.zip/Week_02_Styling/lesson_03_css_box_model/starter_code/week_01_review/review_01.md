# WEEK 01 Review

Fill in the blanks in the HTML & CSS files...

### HTML file
* Line 1
* Lines 2 and 45
* Line 4
* Line 8
* Line 13
* Lines 24 and 25
* Lines 30 and 33
* Lines 38, 39, and 40

### CSS file
* Line 3
* Line 6
* Line 20
* Line 27
* Lines 32 and 33

### Bonus
* Name at least 2 ways I could make the paragraph in the footer element smaller than the rest of the paragraphs?